# Run r-90df2fbd

**Label:** leaky  
**Started:** 2026-10-12T12:14:29.617250+00:00  
**Status:** completed  
**Duration:** 0.202 s

This archive was produced by daftar. It records what generated a
computational result: the code version, parameters, random seeds, input
file hashes, and software environment.

You do not need daftar to read it. `manifest.json` and `fields.tsv`
are plain text and contain everything.

## What produced this

- Entry point: `examples/demo_end_to_end.py::main`
- Git commit: `80c7e79cb154fcc28cb712bd51611b8c5ddf33f3`  **(uncommitted changes were present)**
- Random seed: `42`

## Parameters

- `dt` = `0.025`
- `tau` = `10.0`

## Results

- `v_final` = `9.933041`
- `v_mean` = `8.018358`

## Inputs (sha256 prefix)

- `connectome.csv`: `cf1846663f20`

## Environment

- brian2 2.10.1
- cpm_toolbox 0.26.0.dev0  (from git+https://github.com/DevComPsy/cpm.git@main#43b0c8b3b63f)
- cython 3.1.3
- daftar 1.2.0  (from editable:file:///Users/asataryd/Documents/ENI-Projects/Aslan/B2B%20Scientific%20Startups/Summary%20Feasibility%20Plans/daftar)
- gdm_concordia 2.4.0
- gdsfactory 9.49.0
- jax 0.11.1
- jaxley 0.14.0
- jaxlib 0.11.1
- kfactory 3.0.4
- klayout 0.30.12
- matplotlib 3.11.1
- mne 1.14.0.dev79+gf872b7755  (from git+https://github.com/mne-tools/mne-python.git@main#f872b775540a)
- netpyne 1.1.1
- neuron 9.0.2
- nflows 0.14
- nibabel 5.4.2
- nilearn 0.14.1
- numpy 2.5.2
- pandas 3.0.5
- sbi 0.27.0  (from git+https://github.com/sbi-dev/sbi.git@main#3184ddd864a2)
- scikit_learn 1.8.0
- scipy 1.18.1
- sympy 1.14.0
- torch 2.14.0
- zuko 1.6.0

## Known obstacles to exact reproduction

- working tree was dirty; uncommitted changes were not preserved (diff hash 357accb48213b5c8)
